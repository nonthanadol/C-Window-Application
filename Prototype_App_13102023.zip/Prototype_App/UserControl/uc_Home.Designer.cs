﻿namespace Prototype_App
{
    partial class uc_Home
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbHOME = new System.Windows.Forms.Label();
            this.cboReadFrom = new System.Windows.Forms.ComboBox();
            this.lbReadFrom = new System.Windows.Forms.Label();
            this.btnReadLog = new System.Windows.Forms.Button();
            this.txtBoxTextContent = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // lbHOME
            // 
            this.lbHOME.BackColor = System.Drawing.SystemColors.Info;
            this.lbHOME.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHOME.Location = new System.Drawing.Point(0, 0);
            this.lbHOME.Name = "lbHOME";
            this.lbHOME.Size = new System.Drawing.Size(818, 52);
            this.lbHOME.TabIndex = 5;
            this.lbHOME.Text = "HOME";
            this.lbHOME.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cboReadFrom
            // 
            this.cboReadFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboReadFrom.FormattingEnabled = true;
            this.cboReadFrom.Items.AddRange(new object[] {
            "PLC",
            "Log"});
            this.cboReadFrom.Location = new System.Drawing.Point(193, 93);
            this.cboReadFrom.Name = "cboReadFrom";
            this.cboReadFrom.Size = new System.Drawing.Size(149, 28);
            this.cboReadFrom.TabIndex = 19;
            this.cboReadFrom.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lbReadFrom
            // 
            this.lbReadFrom.AutoSize = true;
            this.lbReadFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbReadFrom.Location = new System.Drawing.Point(39, 96);
            this.lbReadFrom.Name = "lbReadFrom";
            this.lbReadFrom.Size = new System.Drawing.Size(148, 20);
            this.lbReadFrom.TabIndex = 20;
            this.lbReadFrom.Text = "Read Status From :";
            // 
            // btnReadLog
            // 
            this.btnReadLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReadLog.Location = new System.Drawing.Point(446, 206);
            this.btnReadLog.Name = "btnReadLog";
            this.btnReadLog.Size = new System.Drawing.Size(89, 27);
            this.btnReadLog.TabIndex = 21;
            this.btnReadLog.Text = "ReadLog";
            this.btnReadLog.UseVisualStyleBackColor = true;
            this.btnReadLog.Click += new System.EventHandler(this.btnReadLog_Click);
            // 
            // txtBoxTextContent
            // 
            this.txtBoxTextContent.Location = new System.Drawing.Point(446, 93);
            this.txtBoxTextContent.Name = "txtBoxTextContent";
            this.txtBoxTextContent.Size = new System.Drawing.Size(313, 96);
            this.txtBoxTextContent.TabIndex = 22;
            this.txtBoxTextContent.Text = "";
            // 
            // uc_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtBoxTextContent);
            this.Controls.Add(this.btnReadLog);
            this.Controls.Add(this.lbReadFrom);
            this.Controls.Add(this.cboReadFrom);
            this.Controls.Add(this.lbHOME);
            this.Name = "uc_Home";
            this.Size = new System.Drawing.Size(818, 533);
            this.Load += new System.EventHandler(this.uc_Home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbHOME;
        private System.Windows.Forms.ComboBox cboReadFrom;
        private System.Windows.Forms.Label lbReadFrom;
        private System.Windows.Forms.Button btnReadLog;
        private System.Windows.Forms.RichTextBox txtBoxTextContent;
    }
}
