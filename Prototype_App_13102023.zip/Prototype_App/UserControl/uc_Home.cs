﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Prototype_App
{
    public partial class uc_Home : UserControl
    {
        public uc_Home()
        {
            InitializeComponent();
            
        }
        private void uc_Home_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.EnablePLC)
            {
                cboReadFrom.SelectedItem = "PLC";
                btnReadLog.Enabled = false;
            }
            else
            {
                cboReadFrom.SelectedItem = "Log";
                btnReadLog.Enabled = true;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboReadFrom.SelectedIndex == 0)
            {
                Properties.Settings.Default.EnablePLC = true;
                Properties.Settings.Default.EnableLog = false;
                btnReadLog.Enabled = false;
            }
            else
            {
                Properties.Settings.Default.EnableLog = true;
                Properties.Settings.Default.EnablePLC = false;
                btnReadLog.Enabled = true;
            }

            Properties.Settings.Default.Save();
        }

        private void btnReadLog_Click(object sender, EventArgs e)
        {
            string textfile = @"C:\Users\nonthanadol\Desktop\C#\DataTest\logStatus.txt";
            if (File.Exists(textfile))
            {
                string textContent = File.ReadAllText(textfile);
                txtBoxTextContent.Text = textContent;
            
            }
        }
    }
}
